# Copyright (c) Jupyter Development Team.
# Distributed under the terms of the Modified BSD License.

version_info = (0, 1, 2)
__version__ = '.'.join(map(str, version_info))
